#Required softwares
 Node JS should be installed to run this application.

#Install npm dependencies

1) Open CLI.
2) Goto to project root folder in CLI.
3) run command

npm install

#Run application

After npm packages installation, please run following command

npm start

#Access application

Open following url in any web browser to access the application.

http://localhost:4200/