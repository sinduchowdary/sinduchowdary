import { Injectable, EventEmitter } from '@angular/core';
import { Http, Response } from "@angular/http";
import "rxjs/Rx";

@Injectable()
export class TransactionService {
    currentTransaction = new EventEmitter<any>();
    constructor(private http: Http) {
    }
    getcurrentTransaction() {
    return this.currentTransaction;
    }

    getRecentTransactions() {
    return this.http.get("/src/services/transactions.json")
        .map((response:Response)=>{
            return response.json().data;
        }).toPromise();
    }
}
