import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-header',
  template: `
    <div class="header">
      <img class="logo" src="src/assets/logo.jpg" alt="logo">
    </div>`,
  styles: [` .header {
               height:50px;
               width:100%;
               border-bottom: 3px solid #ff854a;
               padding:10px 0;
              }`,
            `.logo {
                position:relative;
                left:100px;
                height:30px;
            }`
          ]
  
})
export class Header {
}
