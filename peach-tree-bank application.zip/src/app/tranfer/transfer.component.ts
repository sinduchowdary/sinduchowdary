import { Component, EventEmitter, Input, Output } from '@angular/core';
import { TransactionService } from './../../services/transactions.service'

function Transaction(amount, merchant){
  this.amount = amount;
  this.merchant = merchant;
  this.transactionDate = new Date().getTime();
  this.transactionType = "Card Payment";
  this.categoryCode = "#12a580";
}

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent {
 accBalance;
 transaction;
 isPreview;
 constructor(private _TransactionService:TransactionService){}
 ngOnInit() {
    this.accBalance = 5824.76;
    this.transaction = {
      amount:"",
      merchant:"Georgia Power Electric Company"
    };
  }
  reset(){
    this.transaction = {};
  }
  onTransferClick () {
    this.accBalance = this.accBalance - this.transaction.amount;
    this.isPreview = false;
    this._TransactionService.currentTransaction.emit(new Transaction(this.transaction.amount, this.transaction.merchant));
    this.reset();
}
  onSubmitClick () {
    this.isPreview = true;
  }
}
