/* Authors       : Sindhura Kotapati and Deepika Nallamothu.
   Date          : 05/04/2015.
   Description   : Working with Vehicle Rental System by using SQL Queries.
*/




import java.sql.*;
import java.io.*;
import java.util.*;

class project
{

    static BufferedReader keyboard;  // Needed for keyboard I/O.
    static Connection conn; // A connection to the DB must be established
                            // before requests can be handled.  You should
                            // have only one connection.
    static Statement stmt;  // Requests are sent via Statements.  You need
                            // one statement for every request you have
                            // open at the same time.




    // "main" iss where the connection to the database is made, and
    // where I/O is presented to allow the user to direct requests to
    // the methods that actually do the work.
public static void main (String args [])
        throws IOException
    {
        System.out.println("************************************************************");
        System.out.println("USERNAME is sk184");
        System.out.println("Enter the given username:");
        Scanner sc=new Scanner(System.in);    
        String username=sc.nextLine();
        System.out.println("************************************************************");
        System.out.println("PASSWORD is nf68cZNr");
        System.out.println("Enter the given password:");
        Scanner sc1=new Scanner(System.in);    
        String password=sc.nextLine();
        int i=0;


        keyboard = new BufferedReader(new InputStreamReader (System.in));

        try { //Errors will throw a "SQLException" (caught below)

            // Load the Oracle JDBC driver
           DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());

            System.out.println("Registered the driver...");

           // Connect to the database.  The first argument is the
            // connection string, the second is your username, the third is
            // your password.
            conn = DriverManager.getConnection (
                   "jdbc:oracle:thin:@oracle1.wiu.edu:1521/toolman.wiu.edu",
                    username, password);

            conn.setAutoCommit(false);

            System.out.println("logged into oracle as " + username);
            //prints the menu choice and provides the selection option for the user
            while (i != 3) 
            {
                
                System.out.println();
                System.out.println("-------------------------------------------------------------");;
                System.out.println("*************************MENU CHOICE*************************");
                System.out.println("-------------------------------------------------------------");
                System.out.println("Enter 1 for MANAGER MENU");
                System.out.println("Enter 2 for CUSTOMER MENU");
                System.out.println("Enter 3 to EXIT");
                System.out.println("Enter your choice");
                //reads the input from the user
                Scanner sc5=new Scanner(System.in);
                i=sc5.nextInt();
                if(i==1)
                {
                  Manager();   
                }//end of if 
                if(i==2)
                {
                   Customer();
                }//end of if
                if(i==3)
                {
                   System.exit(0); 
                }//end of if
            }//end of while
        }//end of try    
            catch(SQLException e )
            {
                System.out.println("Caught SQL Exception: \n     " + e);
            }
        }

        public static void menu() throws SQLException
        {
            //used for selecting the required option from the menu choice
            int i=0;
            while (i != 3) 
            {
                System.out.println();
                System.out.println("-------------------------------------------------------------");;
                System.out.println("*************************MENU CHOICE*************************");
                System.out.println("-------------------------------------------------------------");
                System.out.println("Enter 1 for MANAGER MENU");
                System.out.println("Enter 2 for CUSTOMER MENU");
                System.out.println("Enter 3 to EXIT");
                System.out.println("Enter your choice");
                Scanner sc2=new Scanner(System.in);
                i=sc2.nextInt();
                if(i==1)
                {
                  Manager();
                }//end of if 
                if(i==2)
                {
                   Customer();
                }//end of if
                if(i==3)
                {
                   System.exit(0); 
                }//end of if
            }//end of while
        }//enf of method    

    private static void Manager() {
        //throw new UnsupportedOperationException("Not supported yet.")
    try
    {
        //provides the menu choice for the user who registered as manager
        stmt=conn.createStatement();
        int i=0;
        while (i!=5)
        {
            
                        System.out.println();
                        System.out.println("------------------------------------------------------------");
                        System.out.println("*************************MANAGER MENU***********************");
                        System.out.println("------------------------------------------------------------");
                        System.out.println("Enter 1 to insert");
                        System.out.println("Enter 2 to update");
                        System.out.println("Enter 3 to delete");
                        System.out.println("Enter 4 for data obsolescence");
                        System.out.println("Enter 5 to return back to the menu choice");
                        System.out.println("Enter your choice");
                        Scanner sc4=new Scanner(System.in);
                        int j=sc4.nextInt();
                        if (j==1)
                        {
                            insert();
                        }//end of if
                        else if(j==2)
                        {
                            update();
                        }//end of else if
                        
                        
                        else if(j==3)
                        {
                            delete();
                        }//end of else
                        else if(j==4)
                        {
                            dataObsolence();
                        }//end of else
                        else
                        {
                            menu();
                        } //end of else
        }//end of while
    }//end of try    
            
            
         catch(SQLException e)
       {
           System.out.println(e.getMessage());
       }//end of catch   
            
    }//end of method    
        
   private static void Customer() {
       //provides the menu choice for the user who registered as customer
        //throw new UnsupportedOperationException("Not supported yet.")
        try
        {    
          stmt=conn.createStatement();
          int i=0;
          while (i!=6)
            {  
        
        
                    System.out.println();
                    System.out.println("------------------------------------------------------------");
                    System.out.println("**********************CUSTOMER MENU*************************");
                    System.out.println("------------------------------------------------------------");
                    System.out.println("Enter 1 for joins");
                    System.out.println("Enter 2 for advance sql features");
                    System.out.println("Enter 3 for built-in functions");
                    System.out.println("Enter 4 for input from user");
                    System.out.println("Enter 5 for brilliance solution");
                    System.out.println("Enter 6 to return to the menu choice");
                    System.out.println("Enter your choice");
                    Scanner sc4=new Scanner(System.in);
                    int c=sc4.nextInt();
                    System.out.println();
                       if(c==1)
                        {
                            joins();
                        }//end of else
                        else if(c==2)
                        {
                            advSqlFeatures();
                        }//end of else    
                        else if(c==3)
                        {
                            builtInFunctions();
                        }//end of else    
                        else if(c==4)
                        {
                            userInput();
                        }//end of else    
                        else if(c==5)
                        {
                            brillianceSolution();
                        }//end of else
                        else
                        {
                           menu(); 
                        }//end of else
            }//end of while
        }//end of try  
                           
           
         catch(SQLException e)
       {
           System.out.println(e.getMessage());
       }//end of catch 
        
}//end of customer method    
    
    //Displays vid,vname,typeid,typename for ford manufacturer
    private static void joins() {
        //throw new UnsupportedOperationException("Not supported yet.");
        
       try
       {     
             System.out.println("Displays vid,vname,typeid,typename for ford manufacturer");
             System.out.println();
             ResultSet rset = stmt.executeQuery("select vh.vid,vh.vname,vh.manufacturername,vt.typeid,vt.typename from vehicles vh JOIN vehicletype vt ON vh.typeid=vt.typeid and vh.manufacturername='Ford' ");
             System.out.println("VID \t"+"VNAME \t"+"MANUFACTURERNAME \t"+"TYPEID \t"+"TYPENAME");
             System.out.println();
             while (rset.next())
            {
              System.out.println(rset.getString(1)+"\t"+rset.getString(2)+"\t"+rset.getString(3)+"\t\t\t"+rset.getString(4)+"\t"+rset.getString(5));
                  
            }//end of while
            System.out.println();
       }//end of try
       catch(SQLException e)
       {
           System.out.println(e.getMessage());
       }//end of catch
    }
    //Displays rid,startdate,enddate of the customer with 1120 as custid and min(total cost)>250
    private static void advSqlFeatures() {
        //throw new UnsupportedOperationException("Not supported yet.");
        try
       {
             System.out.println("Displays rid,startdate,enddate of the customer with 1120 as custid and min(total cost)>250"); 
             System.out.println();
             ResultSet rset = stmt.executeQuery("select rid,startdate,enddate,custname,min(totalcost) from reservations resr join customer cust on resr.custid=1120 and cust.custid=resr.custid  group by rid,startdate,enddate,custname having min(totalcost)>250");
             System.out.println("RID \t"+"STARTDATE \t"+"ENDDATE \t"+"CUSTNAME \t"+"MIN(TOTAL COST)");
             System.out.println();
             while (rset.next())
            {
              System.out.println(rset.getString(1)+"\t"+rset.getString(2)+"\t"+rset.getString(3)+"\t"+rset.getString(4)+"\t\t"+rset.getString(5));
                  
            }//end of while
            System.out.println();
       }//end of try
       catch(SQLException e)
       {
          System.out.println(e.getMessage());
       }//end of catch   
    }//end of main
    
    //Retrieves the details of company and branch whose branch name is ‘Peoria’ and has same cid more than once
    private static void builtInFunctions() {
        //throw new UnsupportedOperationException("Not supported yet."); 

         try
       {
             System.out.println("Retrieves the details of company and branch whose branch name is ‘Peoria’ and has same cid more than once");
             System.out.println();
             ResultSet rset = stmt.executeQuery("select count(c.cid),cname,bname from company c,branches b where b.cid=c.cid and b.bname='Peoria' group by cname,bname having count(c.cid)>1");
             System.out.println("COUNT(C.CID) \t"+"CNAME \t"+"BNAME");
             while (rset.next())
            {
              System.out.println(rset.getString(1)+"\t\t"+rset.getString(2)+"\t"+rset.getString(3));
                  
            }//end of while
    
       }//end of try
       catch(SQLException e)
       {
          System.out.println(e.getMessage());
       }//end of catch 
    }

    //Retrieves all the details of vehicles and branches based on branch id (bid) taking it as input from the user
    private static void userInput() {
        //throw new UnsupportedOperationException("Not supported yet."); 
        
         try
       {
            System.out.println("Retrieves all the details of vehicles and branches based on branch id (bid) taking it as input from the user");
            System.out.println("Enter branch id like 160 for example");
            int brnchid=Integer.parseInt(keyboard.readLine());
            System.out.println();
            ResultSet rset = stmt.executeQuery("select vh.vid,vh.vname,vh.manufacturername,b.bname from vehicles vh,vehiclesinbranches vib,branches b where vh.vid=vib.vid and b.bid=vib.bid and b.bid='"+brnchid+"'");
            System.out.println("VID \t"+"VNAME \t"+"MANUFACTURERNAME \t"+"BNAME");
            System.out.println();
             while (rset.next())
            {
              System.out.println(rset.getString(1)+"\t"+rset.getString(2)+"\t"+rset.getString(3)+"\t\t\t"+rset.getString(4));
                  
            }//end of while
            System.out.println();
       }//end of try
       catch(IOException |SQLException e)
       {
          System.out.println(e.getMessage());
       }//end of catch 
        
    }

    //Retrieve the details of reservations, services, vehicletype and vehicles of each cutomer
    private static void brillianceSolution() {
        //throw new UnsupportedOperationException("Not supported yet.");
        try
       {
             System.out.println("Retrieve the details of reservations, services, vehicletype and vehicles of each cutomer");
             System.out.println();
             ResultSet rset = stmt.executeQuery("select cust.custid,cust.custname,res.startdate,res.totalcost,vt.typename,veh.vname,s.sname from customer cust INNER JOIN reservations res ON cust.custid=res.custid INNER JOIN services s ON s.rid=res.rid INNER JOIN vehicles veh ON veh.vid=res.vid INNER JOIN  vehicletype vt ON vt.typeid=veh.typeid");
             System.out.println("CUSTID \t"+"CUSTNAME \t\t"+"STARTDATE \t\t"+"TOTALCOST \t"+"TYPENAME \t\t"+"VNAME \t\t"+"SNAME");
             System.out.println();
             while (rset.next())
            {
              System.out.println(rset.getString(1)+"\t"+rset.getString(2)+"\t\t\t"+rset.getString(3)+"\t\t"+rset.getString(4)+"\t\t"+rset.getString(5)+"\t\t\t"+rset.getString(6)+"\t\t"+rset.getString(7));
                  
            }//end of while
            System.out.println();
       }//end of try
       catch(SQLException e)
       {
          System.out.println(e.getMessage());
       }//end of catch  
    
    }
            
    //Inserts the data in to vehicles table as per the user requirement
    private static void insert() {
        //throw new UnsupportedOperationException("Not supported yet.");
       try{
        
        System.out.println("Inserts the data in to vehicles table as per the user requirement");
        System.out.println("Enter vehicle id like 4569 for example");
        int vid=Integer.parseInt(keyboard.readLine());
        System.out.println("Enter vehicle name like altima for example");
        String vname=keyboard.readLine();
        System.out.println("Enter manufacture name like nissan for example");
        String mname=keyboard.readLine();
        System.out.println("Enter cost of vehicle like 113 for example");
        int cost=Integer.parseInt(keyboard.readLine());
        System.out.println("Enter typeid like 10 for example");
        int tid=Integer.parseInt(keyboard.readLine());
        //stmt.executeQuery("insert into vehicles Values("+ vid +" ','" + vname + "','" + mname +" ','" + cost+"','"+tid + ")");
        //stmt.executeQuery("insert into locations Values("+ id +",'" + locname + "','" + desc + "')");
        
        stmt.executeQuery("insert into vehicles Values("+ vid +" ,'" + vname + "','" + mname +" ','" + cost+"','"+tid + "')"  );
        conn.commit();
        System.out.println("Insertion is completed");
        System.out.println();

       }//end of try
       catch(IOException | SQLException e)
       {
           System.out.println(e.getMessage());
       }//end of catch

                //To change body of generated methods, choose Tools | Templates.
    }
    
    //Updates the contents in the customer table as prescribed by the user
    private static void update() {
        //throw new UnsupportedOperationException("Not supported yet.");
        try{
        System.out.println("Updates the contents in the customer table as prescribed by the user");   
        System.out.println("Enter customer id like 1234,1321,1543 for example");
        int cid=Integer.parseInt(keyboard.readLine());
        System.out.println("Enter customer name");
        String cname=keyboard.readLine();
        
        stmt.executeQuery("update customer set custname='"
		   + cname + "' where custid=" + cid);
        conn.commit();
        System.out.println("Updation is completed");
        System.out.println();
        
        //stmt.executeQuery("update locations  set loc_name='"
		  // + locname + "' where loc_ID=" + locid);
                   
        }//end of try
        catch(IOException | SQLException e)
       {
           System.out.println(e.getMessage());
       }//end of catch
        
        
        
    }

    //Deletes the data from the vehicletype table as presecribed the user
    private static void delete() {
        //throw new UnsupportedOperationException("Not supported yet.");
        try{
        System.out.println("Deletes the data from the vehicletype table as presecribed the user");    
        System.out.println("Enter vehicle typeid like 19,29,17,27 for example");
        int tid=Integer.parseInt(keyboard.readLine());
        stmt.executeQuery("delete from vehicletype where typeid ="+tid+"");
        conn.commit();
        System.out.println("Deletion is completed");
        System.out.println();          
        //stmt.executeQuery("delete from locations where loc_id ='"+locid+"'");          
                   
        }//end of try
        catch(IOException | SQLException e)
       {
           System.out.println(e.getMessage());
       }//end of catch
        
    }

    //Deletes the given data in the reservations table as per the requirement
    private static void dataObsolence() {
        //throw new UnsupportedOperationException("Not supported yet."); 
         try{
                stmt=conn.createStatement();
               
                System.out.println("Deletes the given data in the reservations table as per the requirement");
                ResultSet rs=stmt.executeQuery("select rid from services sc  INNER JOIN reservations resr ON resr.rid=sc.rid and trunc(resr.startdate)<'06-MAY-1994'");        
                
             
            
                while (rs.next()) 
                {
                   //System.out.println();
                   int rid = rs.getInt(1);

                   System.out.println(rid);
                   ResultSet r1 = stmt.executeQuery("DELETE FROM services where rid=" + rid);
                   System.out.println(" record deleted");

                   ResultSet r2 = stmt.executeQuery("DELETE FROM reservations where rid="+ rid);
                   System.out.println("deleted");

               }
                if (!rs.next())
               {
                   System.out.println("No reservation dates are stored before may");
               }

               rs.close();

                conn.commit();
                System.out.println("Data obsolence is completed");
                System.out.println();

               //stmt.executeQuery("delete from locations where loc_id ='"+locid+"'");          

        }//end of try
        catch(SQLException e)
       {
           System.out.println(e.getMessage());
       }//end of catch
        
    }
}
