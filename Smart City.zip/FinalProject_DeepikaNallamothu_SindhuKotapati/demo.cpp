// CS 465
// City 
// Author: Group
/* Group members:
					Deepika Nallamothu
					Sindhura Kotapati
*/
#include "../shared/gltools.h"	// OpenGL toolkit
#include <iostream>
#include <time.h>       /* time */
#include "../shared/math3d.h"
float sunRotationAngle = 0;
#define PI 3.14159265
#define MOVEDELTA 0.5f
#define ANGLEDELTA 2.0f
#define c 3.14/180
#define PI  3.14
#define TWO_PI  2.0 * PI
#define RAD_TO_DEG  180.0 / PI
float angle; //Rotation angle for car

float carx = 0, cary = 570; //Variables that specify position of the car

int rot = 0; //rotation angle for the wheels
			 //Coordinates for the chassis of the car

float p[] = { 5.5, -2.5, 1 }, q[] = { 5.5, -7.5, 1 }, r[] = { 10.7, -7.5, 1 }, s[] = { 10.7, -2.5, 1 };

float p1[] = { 10.7, -9, 3 }, s1[] = { 12.7, -9, 3 }, q1[] = { 10.7, -1, 3 }, r1[] = { 12.7, -1, 3 };

float p2[] = { 0.5, -1, 1 }, s2[] = { 5.5, -1, 1 }, q2[] = { 0.5, -9, 1 }, r2[] = { 5.5, -9, 1 };

float p3[] = { -15, -6.5, 1 }, q3[] = { -15, -3.5, 1 }, r3[] = { 0.5, -2.5, 1 }, s3[] = { 0.5, -7.5, 1 };

float p4[] = { -13, -6.5, 1 }, q4[] = { -13, -6.5, 2.5 }, r4[] = { 0.5, -7.5, 3.5 }, s4[] = { 0.5, -7.5, 1 };

float p5[] = { -13, -3.5, 1 }, q5[] = { -13, -3.5, 2.5 }, r5[] = { 0.5, -2.5, 3.5 }, s5[] = { 0.5, -2.5, 1 };

float p6[] = { 5.5, -2.5, 1 }, q6[] = { 5.5, -2.5, 3.5 }, r6[] = { 10.7, -2.5, 3.5 }, s6[] = { 10.7, -2.5, 1 };

float p7[] = { 5.5, -7.5, 1 }, q7[] = { 5.5, -7.5, 3.5 }, r7[] = { 10.7, -7.5, 3.5 }, s7[] = { 10.7, -7.5, 1 };

float p8[] = { 5.5, -7.5, 3.5 }, q8[] = { 10.7, -7.5, 3.5 }, r8[] = { 10.7, -6, 3.5 }, s8[] = { 5.5, -6, 3.5 };

float p9[] = { 5.5, -2.5, 3.5 }, q9[] = { 5.5, -4, 3.5 }, r9[] = { 10.7, -4, 3.5 }, s9[] = { 10.7, -2.5, 3.5 };

float p10[] = { 5.5, -4, 3.5 }, q10[] = { 10.7, -4, 3.5 }, r10[] = { 10.7, -5, 4.5 }, s10[] = { 5.5, -5, 5.5 };

float p11[] = { 5.5, -6, 3.5 }, q11[] = { 10.7, -6, 3.5 }, r11[] = { 10.7, -5, 4.5 }, s11[] = { 5.5, -5, 5.5 };

float p12[] = { 10.7, -9, 2 }, q12[] = { 10.7, -9, 4 }, r12[] = { 12.7, -9, 4 }, s12[] = { 12.7, -9, 2 };

float p13[] = { 10.7, -1, 2 }, q13[] = { 10.7, -1, 4 }, r13[] = { 12.7, -1, 4 }, s13[] = { 12.7, -1, 2 };

float p14[] = { 0.5, -1, 1 }, q14[] = { 0.5, -1, 3 }, r14[] = { 5.5, -1, 3 }, s14[] = { 5.5, -1, 1 };

float p15[] = { 0.5, -9, 1 }, q15[] = { 0.5, -9, 3 }, r15[] = { 5.5, -9, 3 }, s15[] = { 5.5, -9, 1 };

float p16[] = { 0.5, -1, 1 }, q16[] = { 0.5, -1, 3 }, r16[] = { 0.5, -2.5, 3.5 }, s16[] = { 0.5, -2.5, 1 };

float p17[] = { 0.5, -7.5, 1 }, q17[] = { 0.5, -7.5, 3.5 }, r17[] = { 0.5, -9, 3 }, s17[] = { 0.5, -9, 1 };

float p18[] = { 5.5, -1, 1 }, q18[] = { 5.5, -1, 3 }, r18[] = { 5.5, -2.5, 3.5 }, s18[] = { 5.5, -2.5, 1 };

float p19[] = { 5.5, -7.5, 1 }, q19[] = { 5.5, -7.5, 3.5 }, r19[] = { 5.5, -9, 3 }, s19[] = { 5.5, -9, 1 };

float p20[] = { 10.7, -7.5, 1 }, q20[] = { 10.7, -7.5, 3.5 }, r20[] = { 10.7, -2.5, 3.5 },
s20[] = { 10.7, -2.5, 1 };

float p21[] = { 4, -2.5, 3.5 }, q21[] = { 5.5, -2.5, 3.5 }, r21[] = { 5.5, -7.5, 3.5 }, s21[] = { 4, -7.5, 3.5 };

float spin = 0;
bool lookUp;
bool lookDown;
bool lookLeft;
bool lookRight;
bool walkForward;
bool walkBackward;
bool strafeLeft;
bool strafeRight;
float objectYRotation = 0;
float xCameraLocation;
float yCameraLocation;
float zCameraLocation;
float xTranslation;
float yTranslation;
float zTranslation;
float yRotationAngle;
float zRotationAngle;
float xRotationAngle;
int mouseLastx;
int mouseLasty;
// Transformation matrix to project shadow

M3DVector4f vPlaneEquation;

// Light values and coordinates
GLfloat	 lightPos[] = { 0.0f, 0.0f, 0.0f, 1.0f };
GLfloat  specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
GLfloat  diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
GLfloat  specref[] = { 1.0f, 1.0f, 1.0f, 1.0f };
GLfloat  ambientLight[] = { 0.2f, 0.2f, 0.2f, 1.0f };
GLfloat  ambientNoLight[] = { 0.0f, 0.0f, 0.0f, 1.0f };

GLfloat	 none[] = { 0.0f, 0.0f, 0.0f, 1.0f };
GLfloat  full[] = { 1.0f, 1.0f, 1.0f, 1.0f };

bool specularFlag = true;
bool diffuseFlag = true;
bool ambientFlag = true;
bool smoothFlag = true;
bool warped = false;
#define NUM_TEXTURES 9
#define B1 0
#define B2 1
#define B3 2
#define B4 3
#define B5 4
#define FLOOR 5
#define SPEED_SCALE 6
#define PARTICLE 7
#define BALL 8

#define MAX_PARTICLES 10000
GLuint  textureObjects[NUM_TEXTURES];
// Six sides of a cube map
const char *szCubeFaces[6] = { "GalaxyBK.tga", "GalaxyDn.tga", "GalaxyFt.tga", "GalaxyLf.tga", "GalaxyRt.tga", "GalaxyUp.tga" };

GLenum  cube[6] = { GL_TEXTURE_CUBE_MAP_POSITIVE_X,
GL_TEXTURE_CUBE_MAP_NEGATIVE_X,
GL_TEXTURE_CUBE_MAP_POSITIVE_Y,
GL_TEXTURE_CUBE_MAP_NEGATIVE_Y,
GL_TEXTURE_CUBE_MAP_POSITIVE_Z,
GL_TEXTURE_CUBE_MAP_NEGATIVE_Z };

void shadowMatrix(GLfloat shadowMat[4][4], GLfloat groundplane[4], GLfloat lightpos[4])
{
	GLfloat dot;
	/* Find dot product between light position vector and ground plane normal. */
	dot = groundplane[0] * lightpos[0] +
		groundplane[1] * lightpos[1] +
		groundplane[2] * lightpos[2] +
		groundplane[3] * lightpos[3];
	shadowMat[0][0] = dot - lightpos[0] * groundplane[0];
	shadowMat[1][0] = 0.f - lightpos[0] * groundplane[1];
	shadowMat[2][0] = 0.f - lightpos[0] * groundplane[2];
	shadowMat[3][0] = 0.f - lightpos[0] * groundplane[3];
	shadowMat[0][1] = 0.f - lightpos[1] * groundplane[0];
	shadowMat[1][1] = dot - lightpos[1] * groundplane[1];
	shadowMat[2][1] = 0.f - lightpos[1] * groundplane[2];
	shadowMat[3][1] = 0.f - lightpos[1] * groundplane[3];
	shadowMat[0][2] = 0.f - lightpos[2] * groundplane[0];
	shadowMat[1][2] = 0.f - lightpos[2] * groundplane[1];
	shadowMat[2][2] = dot - lightpos[2] * groundplane[2];
	shadowMat[3][2] = 0.f - lightpos[2] * groundplane[3];
	shadowMat[0][3] = 0.f - lightpos[3] * groundplane[0];
	shadowMat[1][3] = 0.f - lightpos[3] * groundplane[1];
	shadowMat[2][3] = 0.f - lightpos[3] * groundplane[2];
	shadowMat[3][3] = dot - lightpos[3] * groundplane[3];
}

void mouseMovement(int x, int y)
{
	if (!warped)
	{
		int mouseDiffx = x - glutGet(GLUT_WINDOW_WIDTH) / 2;
		int mouseDiffy = y - glutGet(GLUT_WINDOW_HEIGHT) / 2;
		glutWarpPointer(glutGet(GLUT_WINDOW_WIDTH) / 2, glutGet(GLUT_WINDOW_HEIGHT) / 2);
		mouseLastx = x;
		mouseLasty = y; //set lasty to the current y position
		xRotationAngle -= ((GLfloat)mouseDiffy)*0.1;
		yRotationAngle += ((GLfloat)mouseDiffx)*0.1;
		if (xRotationAngle >= 90)
			xRotationAngle = 90;
		if (xRotationAngle <= -90)
			xRotationAngle = -90;
		warped = true;
	}
}

struct particles				// Create A Structure For Particle
{
	float   speed;				    //speed along the movement vector
	float	life;					// Particle Life
	float   fade;				    // fade delta
	float	r;						// Red Value
	float	g;						// Green Value
	float	b;						// Blue Value
	float	x;						// X Position
	float	y;						// Y Position
	float	z;						// Z Position
	float	dx;						// X Direction
	float	dy;						// Y Direction
	float	dz;						// Z Direction
};							// Particles Structure

particles particle[MAX_PARTICLES];	// Particle Array (Room For Particle Info)

float randomFloat(float min, float max)
{
	return min + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (max - min)));
}

void initParticle(int index)
{
	particle[index].r = 1;
	particle[index].g = 1;
	particle[index].b = 1;

	particle[index].x = 0;
	particle[index].y = 0;
	particle[index].z = 0;

	particle[index].dx = randomFloat(-1, 1);
	particle[index].dy = randomFloat(-1, 1);
	particle[index].dz = randomFloat(-1, 1);
	particle[index].life = 0.2;

	particle[index].fade = randomFloat(0.1, 1.1);

	particle[index].speed = randomFloat(0, 1) * SPEED_SCALE;

}

void initParticles()
{
	srand(time(NULL));
	for (int i = 0; i<MAX_PARTICLES; i++)
		initParticle(i);
}

void drawParticles()
{
	float deltaTime = 1.f / 60.f;
	glDisable(GL_LIGHTING);
	//glDisable (GL_DEPTH_TEST);
	glDepthMask(GL_FALSE);
	glEnable(GL_BLEND);									// Enable Blending
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);					// Type Of Blending To Perform
														//glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);	
	glBindTexture(GL_TEXTURE_2D, textureObjects[PARTICLE]);
	glTexEnvi(GL_POINT_SPRITE, GL_COORD_REPLACE, GL_TRUE); //sets coordinates from 0 to 1 in each direction for the quad
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glEnable(GL_POINT_SPRITE);
	glEnable(GL_TEXTURE_2D);

	glPointSize(10.0f);      // 5.5
	glBegin(GL_POINTS);
	for (int i = 0; i<MAX_PARTICLES; i++)
	{
		if (particle[i].life < 0)
			initParticle(i);

		particle[i].dy += 2.0 * deltaTime*particle[i].speed;

		particle[i].x += particle[i].dx * deltaTime * particle[i].speed;
		particle[i].y += particle[i].dy * deltaTime * particle[i].speed;
		particle[i].z += particle[i].dz * deltaTime * particle[i].speed;
		if (particle[i].life > -0.001)
		{
			particle[i].b -= -2 * particle[i].fade * deltaTime;
			particle[i].r += -2 * particle[i].fade * deltaTime;
		}
		else
		{
			particle[i].g -= -2 * particle[i].fade * deltaTime;
			particle[i].r -= -2 * particle[i].fade * deltaTime;
		}


		particle[i].life -= particle[i].fade * deltaTime;

		// Draw The Particle Using Our RGB Values, Fade The Particle Based On Its Life
		glColor4f(particle[i].r, particle[i].g, particle[i].b, particle[i].life);

		glVertex3f(particle[i].x, particle[i].y, particle[i].z); // Top Righ

	}
	glEnd();
	glDisable(GL_BLEND);									// Enable Blending
	glDisable(GL_POINT_SPRITE);
	glEnable(GL_LIGHTING);
	glDepthMask(GL_TRUE);
	glEnable(GL_DEPTH_TEST);
}

void DrawSkyBox(void)
{
	GLfloat fExtent = 500.0f;
	glEnable(GL_TEXTURE_CUBE_MAP);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
	glBegin(GL_QUADS);
	//////////////////////////////////////////////
	// Negative X
	glTexCoord3f(-1.0f, -1.0f, 1.0f);
	glVertex3f(-fExtent, -fExtent, fExtent);

	glTexCoord3f(-1.0f, -1.0f, -1.0f);
	glVertex3f(-fExtent, -fExtent, -fExtent);

	glTexCoord3f(-1.0f, 1.0f, -1.0f);
	glVertex3f(-fExtent, fExtent, -fExtent);

	glTexCoord3f(-1.0f, 1.0f, 1.0f);
	glVertex3f(-fExtent, fExtent, fExtent);

	///////////////////////////////////////////////
	//  Postive X
	glTexCoord3f(1.0f, -1.0f, -1.0f);
	glVertex3f(fExtent, -fExtent, -fExtent);

	glTexCoord3f(1.0f, -1.0f, 1.0f);
	glVertex3f(fExtent, -fExtent, fExtent);

	glTexCoord3f(1.0f, 1.0f, 1.0f);
	glVertex3f(fExtent, fExtent, fExtent);

	glTexCoord3f(1.0f, 1.0f, -1.0f);
	glVertex3f(fExtent, fExtent, -fExtent);

	////////////////////////////////////////////////
	// Negative Z 
	glTexCoord3f(-1.0f, -1.0f, -1.0f);
	glVertex3f(-fExtent, -fExtent, -fExtent);

	glTexCoord3f(1.0f, -1.0f, -1.0f);
	glVertex3f(fExtent, -fExtent, -fExtent);

	glTexCoord3f(1.0f, 1.0f, -1.0f);
	glVertex3f(fExtent, fExtent, -fExtent);

	glTexCoord3f(-1.0f, 1.0f, -1.0f);
	glVertex3f(-fExtent, fExtent, -fExtent);

	////////////////////////////////////////////////
	// Positive Z 
	glTexCoord3f(1.0f, -1.0f, 1.0f);
	glVertex3f(fExtent, -fExtent, fExtent);

	glTexCoord3f(-1.0f, -1.0f, 1.0f);
	glVertex3f(-fExtent, -fExtent, fExtent);

	glTexCoord3f(-1.0f, 1.0f, 1.0f);
	glVertex3f(-fExtent, fExtent, fExtent);

	glTexCoord3f(1.0f, 1.0f, 1.0f);
	glVertex3f(fExtent, fExtent, fExtent);

	//////////////////////////////////////////////////
	// Positive Y
	glTexCoord3f(-1.0f, 1.0f, 1.0f);
	glVertex3f(-fExtent, fExtent, fExtent);

	glTexCoord3f(-1.0f, 1.0f, -1.0f);
	glVertex3f(-fExtent, fExtent, -fExtent);

	glTexCoord3f(1.0f, 1.0f, -1.0f);
	glVertex3f(fExtent, fExtent, -fExtent);

	glTexCoord3f(1.0f, 1.0f, 1.0f);
	glVertex3f(fExtent, fExtent, fExtent);

	///////////////////////////////////////////////////
	// Negative Y
	glTexCoord3f(-1.0f, -1.0f, -1.0f);
	glVertex3f(-fExtent, -fExtent, -fExtent);

	glTexCoord3f(-1.0f, -1.0f, 1.0f);
	glVertex3f(-fExtent, -fExtent, fExtent);

	glTexCoord3f(1.0f, -1.0f, 1.0f);
	glVertex3f(fExtent, -fExtent, fExtent);

	glTexCoord3f(1.0f, -1.0f, -1.0f);
	glVertex3f(fExtent, -fExtent, -fExtent);
	glEnd();
	glDisable(GL_TEXTURE_CUBE_MAP);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

}
void cylinder(float r, float l)
{
	float x, y, z; int d;
	glBegin(GL_QUAD_STRIP);
	for (d = 0; d <= 362; d += 1)
	{
		x = r*cos(c*d);
		z = r*sin(c*d);
		y = 0;
		glVertex3f(x, y, z);

		y = l;
		glVertex3f(x, y, z);
	}
	glEnd();
}

void alloy(float R1, float R2)
{
	float X, Y, Z; int y;
	glColor3f(1, 1, 1);
	glBegin(GL_QUAD_STRIP);
	for (y = 0; y <= 361; y += 1)
	{
		X = R1*cos(c*y);
		Z = R1*sin(c*y);
		Y = 0;
		glVertex3f(X, Y, Z);

		X = R2*cos(c*y);
		Z = R2*sin(c*y);
		Y = 0;
		glVertex3f(X, Y, Z);

	}
	glEnd();
}
//Function to draw the spokes of the wheel
void actall(float R1, float R2)
{
	float X, Y, Z; int i;
	glBegin(GL_QUADS);
	for (i = 0; i <= 361; i += 120)
	{
		glColor3f(0, 0.5, 0.5);
		X = R1*cos(c*i);
		Y = 0;
		Z = R1*sin(c*i);
		glVertex3f(X, Y, Z);

		X = R1*cos(c*(i + 30));
		Y = 0;
		Z = R1*sin(c*(i + 30));
		glVertex3f(X, Y, Z);

		X = R2*cos(c*(i + 30));
		Y = 0;
		Z = R2*sin(c*(i + 30));
		glVertex3f(X, Y, Z);

		X = R2*cos(c*i);
		Y = 0;
		Z = R2*sin(c*i);
		glVertex3f(X, Y, Z);
	}
	glEnd();
}
//Function to draw a circle
void circle(float R)
{
	float X, Y, Z; int i;

	glBegin(GL_POLYGON);
	for (i = 0; i <= 360; i++)
	{
		X = R*cos(c*i);
		Z = R*sin(c*i);
		Y = 0;
		glVertex3f(X, Y, Z);
	}
	glEnd();
}
void driver()
{
	glColor3f(0.5, 0.2, 0.8);
	//Legs
	glPushMatrix();
	glTranslatef(3, -3.5, 1.5);
	glRotatef(90, 0, 0, 1);
	cylinder(0.4, 3);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(3, -6.5, 1.5);
	glRotatef(90, 0, 0, 1);
	cylinder(0.4, 3);
	glPopMatrix();

	//Hands
	glPushMatrix();
	glTranslatef(3, -3.5, 2.5);
	glRotatef(90, 0, 0, 1);
	cylinder(0.4, 3);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(3, -6.5, 2.5);
	glRotatef(90, 0, 0, 1);
	cylinder(0.4, 3);
	glPopMatrix();

	//Head
	glPushMatrix();
	glTranslatef(3, -5, 4);
	glutSolidSphere(1.0, 20, 16);
	glPopMatrix();

	//Body
	glPushMatrix();
	glTranslatef(3, -5, 1);
	glRotatef(90, 1, 0, 0);
	cylinder(1, 2);
	glPopMatrix();

	//Circle
	glPushMatrix();
	glTranslatef(3, -5, 3);
	glRotatef(90, 1, 0, 0);
	circle(1);
	glPopMatrix();
}
void tri(float a[], float b[], float z[])
{
	glBegin(GL_TRIANGLES);
	glVertex3fv(a);
	glVertex3fv(b);
	glVertex3fv(z);
	glEnd();
}
void rect(float p[], float q[], float r[], float s[])
{
	glBegin(GL_POLYGON);
	glVertex3fv(p);
	glVertex3fv(q);
	glVertex3fv(r);
	glVertex3fv(s);
	glEnd();
}
void wheels()
{
	//axle
	glColor3f(0, 0.5, 0.3);
	cylinder(0.4, 9);

	//1st Wheel
	glColor3f(0, 0, 0);
	cylinder(2, 2);
	alloy(2, 1.4);
	actall(1.4, 0.8);
	glColor3f(0, 0.5, 0.4);
	circle(0.8);

	glPushMatrix();
	glTranslatef(0, 2, 0);
	alloy(2, 1.4);
	actall(1.4, 0.8);
	glColor3f(0, 0.5, 0.4);
	circle(0.8);
	glPopMatrix();

	//2nd Wheel
	glPushMatrix();
	glTranslatef(0, 8, 0);
	glColor3f(0, 0, 0);
	cylinder(2, 2);
	alloy(2, 1.4);
	actall(1.4, 0.8);
	glColor3f(0, 0.5, 0.4);
	circle(0.8);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, 10, 0);
	actall(1.4, 0.8);
	alloy(2, 1.4);
	glColor3f(0, 0.5, 0.4);
	circle(0.8);
	glPopMatrix();
}

//Function that generates the chassis of the car
void chassis()
{
	//Parameters For glMaterialfv() function
	GLfloat specular[] = { 0.7, 0.7, 0.7, 1.0 };
	GLfloat ambient[] = { 1, 1, 1, 1 }, diffuse[] = { 0.7, 0.7, 0.7, 1 };
	GLfloat full_shininess[] = { 100.0 };

	//Material Properties
	glMaterialfv(GL_FRONT, GL_AMBIENT, ambient);
	glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
	glMaterialfv(GL_FRONT, GL_SHININESS, full_shininess);

	glColor3f(0.1960, 0.8, 0.1960);
	
	rect(p, q, r, s);
	rect(p2, q2, r2, s2);
	rect(p3, q3, r3, s3);
	rect(p4, q4, r4, s4);
	rect(p5, q5, r5, s5);
	rect(q5, q4, r4, r5);
	rect(p6, q6, r6, s6);
	rect(p7, q7, r7, s7);
	rect(p8, q8, r8, s8);
	rect(p9, q9, r9, s9);

	glColor3f(0.1960, 0.8, 0.1960);

	rect(p1, q1, r1, s1);
	rect(q5, q4, p3, q3);
	tri(p4, q4, p3);
	tri(p5, q5, q3);
	rect(p10, q10, r10, s10);
	rect(p11, q11, r11, s11);
	rect(r16, r18, q18, q16);
	rect(q17, q19, r19, r17);
	rect(p21, q21, r21, s21);

	glColor3f(0.1960, 0.8, 0.1960);
	
	rect(p12, q12, r12, s12);
	rect(p13, q13, r13, s13);
	rect(p14, q14, r14, s14);
	rect(p15, q15, r15, s15);
	rect(p16, q16, r16, s16);
	rect(p17, q17, r17, s17);
	rect(p18, q18, r18, s18);
	rect(p19, q19, r19, s19);
	rect(r18, q19, p19, s18);
	rect(p20, q20, r20, s20);
}
void car()
{
	glPushMatrix();
	glRotatef(180, 0, 0, 1);

	chassis();

	glPushMatrix();
	glTranslatef(8, -10, 1);
	glRotatef(rot, 0, 1, 0);
	wheels();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-12, -10, 1);
	glRotatef(rot, 0, 1, 0);
	wheels();
	glPopMatrix();

	driver();

	rot += 90;
	if (rot>360) rot -= 360;

	glPopMatrix();
}

void drawPyramids(bool inShadow)
{
	glPushMatrix();
	glTranslatef(-80, 0, -50);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 0, 1);
	else
		glColor3f(0, 0, 0);
	glutWireCone(5, 10, 20, 10);
	//glutSolidTorus(5,10,25,5);
	glFrontFace(GL_CCW);
	glRotatef(90, 1, 0, 0);
	glTranslatef(-10, -10, 100);
	glPopMatrix();

	//tree1
	glColor3f(0, 0.6, 0);

	glPushMatrix();
	glTranslatef(-23, 1, -70);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glScalef(3, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();
	glColor3f(1, 0, 0);
	glPushMatrix();
	glTranslatef(-23, 0.5, -70);
	if (!inShadow)
		glColor3f(1, 0, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCube(1);
	glPopMatrix();

	//tree 2
	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(23, 1, -82);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(23, 4, -82);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(1, 0, 0);
	glPushMatrix();
	glTranslatef(23, 0.5, -82);
	if (!inShadow)
		glColor3f(1, 0, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCube(1);
	glPopMatrix();


	//tree3
	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(-23, 1, -10);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();
	glColor3f(1, 0, 0);
	glPushMatrix();
	glTranslatef(-23, 0.5, -10);
	if (!inShadow)
		glColor3f(1, 0, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCube(1);
	glPopMatrix();

	//tree 4
	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(23, 1, -48);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(23, 4, -48);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(1, 0, 0);
	glPushMatrix();
	glTranslatef(23, 0.5, -48);
	if (!inShadow)
		glColor3f(1, 0, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCube(1);
	glPopMatrix();

	//tree5
	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(-23, 1, -90);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();
	glColor3f(1, 0, 0);
	glPushMatrix();
	glTranslatef(-23, 0.5, -90);
	if (!inShadow)
		glColor3f(1, 0, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCube(1);
	glPopMatrix();

	//tree 6
	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(23, 1, 10);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(23, 4, 10);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(1, 0, 0);
	glPushMatrix();
	glTranslatef(23, 0.5, 10);
	if (!inShadow)
		glColor3f(1, 0, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCube(1);
	glPopMatrix();

	//tree7
	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(-23, 1, 63);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();
	glColor3f(1, 0, 0);
	glPushMatrix();
	glTranslatef(-23, 0.5, 63);
	if (!inShadow)
		glColor3f(1, 0, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCube(1);
	glPopMatrix();

	//tree 8
	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(23, 1, 40);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(23, 4, 40);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(1, 0, 0);
	glPushMatrix();
	glTranslatef(23, 0.5, 40);
	if (!inShadow)
		glColor3f(1, 0, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCube(1);
	glPopMatrix();

	//tree 9
	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(23, 1, 85);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(23, 4, 85);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(1, 0, 0);
	glPushMatrix();
	glTranslatef(23, 0.5, 85);
	if (!inShadow)
		glColor3f(1, 0, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCube(1);
	glPopMatrix();

	//right most lane trees
	//tree 10
	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(-75, 1, 83);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(-75, 4, 83);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(1, 0, 0);
	glPushMatrix();
	glTranslatef(-75, 0.5, 83);
	if (!inShadow)
		glColor3f(1, 0, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCube(1);
	glPopMatrix();

	//tree 11
	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(-75, 1, 30);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(-75, 4, 30);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(1, 0, 0);
	glPushMatrix();
	glTranslatef(-75, 0.5, 30);
	if (!inShadow)
		glColor3f(1, 0, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCube(1);
	glPopMatrix();

	//tree 12
	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(-75, 1, -20);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(-75, 4, -20);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(1, 0, 0);
	glPushMatrix();
	glTranslatef(-75, 0.5, -20);
	if (!inShadow)
		glColor3f(1, 0, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCube(1);
	glPopMatrix();

	//tree 13
	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(-75, 1, -85);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(0, 0.6, 0);
	glPushMatrix();
	glTranslatef(-75, 4, -85);
	glRotatef(-90, 1, 0, 0);
	glMateriali(GL_FRONT, GL_SHININESS, 20);
	glFrontFace(GL_CW);
	if (!inShadow)
		glColor3f(0, 1, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCone(2, 8, 3, 3);
	glFrontFace(GL_CCW);
	glPopMatrix();

	glColor3f(1, 0, 0);
	glPushMatrix();
	glTranslatef(-75, 0.5, -85);
	if (!inShadow)
		glColor3f(1, 0, 0);
	else
		glColor3f(0, 0, 0);
	glutSolidCube(1);
	glPopMatrix();
}
void drawBuilding()
{
	glEnable(GL_LIGHTING);
	glBegin(GL_QUADS);
	glNormal3f(0, 0, -1);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(-5, 10, -5);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(5, 10, -5);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(5, 0, -5);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-5, 0, -5);

	glNormal3f(0, 0, 1);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(5, 10, 5);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-5, 10, 5);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-5, 0, 5);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(5, 0, 5);

	glNormal3f(-1, 0, 0);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(-5, 10, 5);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-5, 10, -5);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-5, 0, -5);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-5, 0, 5);

	glNormal3f(1, 0, 0);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(5, 10, -5);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(5, 10, 5);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(5, 0, 5);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(5, 0, -5);

	glNormal3f(0, 1, 0);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(5, 10, -5);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-5, 10, -5);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-5, 10, 5);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(5, 10, 5);

	glNormal3f(0, -1, 0);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(-5, 0, -5);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(5, 0, -5);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(5, 0, 5);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-5, 0, 5);
	glEnd();
}
void drawPlane() {
	glBegin(GL_QUADS);
	glNormal3f(0, 1, 0);
	for (int i = -100; i <= 100; i += 10)
		for (int j = -100; j <= 100; j += 10)
		{
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(i + 10, 0, j);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(i, 0, j);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(i, 0, j + 10);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(i + 10, 0, j + 10);
		}
	glEnd();
}
void buildings() {
	// building 1
	glPushMatrix();
	glTranslatef(30, 0.1, 80);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B1]);
	drawBuilding();
	glPopMatrix();

	// building 2
	glPushMatrix();
	glScalef(1, 2, 1);
	glTranslatef(30, 0, 60);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B2]);
	drawBuilding();
	glPopMatrix();

	// building 3
	glPushMatrix();
	glScalef(1, 3, 1);
	glTranslatef(30, 0.1, 40);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B3]);
	drawBuilding();
	glPopMatrix();

	// building 4
	glPushMatrix();
	glScalef(1, 2, 1.5);
	glTranslatef(30, 0.1, 15);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B4]);
	drawBuilding();
	glPopMatrix();

	// building 5
	glPushMatrix();
	glScalef(1, 1.5, 1);
	glTranslatef(30, 0.1, 0);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B5]);
	drawBuilding();
	glPopMatrix();

	// building 6
	glPushMatrix();
	glScalef(1, 2, 1);
	glTranslatef(30, 0.1, -40);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B1]);
	drawBuilding();
	glPopMatrix();

	// building 7
	glPushMatrix();
	glScalef(1, 2.5, 1);
	glTranslatef(30, 0.1, -60);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B2]);
	drawBuilding();
	glPopMatrix();

	// building 8
	glPushMatrix();
	glScalef(1, 2, 1);
	glTranslatef(-30, 0.1, 80);
	glRotatef(180, 0, 1, 0);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B3]);
	drawBuilding();
	glPopMatrix();

	// building 9
	glPushMatrix();
	glScalef(1, 1, 1);
	glTranslatef(-30, 0.1, 35);
	glRotatef(180, 0, 1, 0);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B4]);
	drawBuilding();
	glPopMatrix();

	// building 10
	glPushMatrix();
	glScalef(1, 2, 1);
	glTranslatef(-30, 0.1, 10);
	glRotatef(180, 0, 1, 0);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B5]);
	drawBuilding();
	glPopMatrix();

	// building 11
	glPushMatrix();
	glScalef(1, 2, 1);
	glTranslatef(-30, 0.1, -20);
	glRotatef(180, 0, 1, 0);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B1]);
	drawBuilding();
	glPopMatrix();

	// building 12
	glPushMatrix();
	glScalef(1, 2, 1);
	glTranslatef(-30, 0.1, -40);
	glRotatef(180, 0, 1, 0);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B2]);
	drawBuilding();
	glPopMatrix();

	// building 13
	glPushMatrix();
	glScalef(1, 1.5, 1);
	glTranslatef(-30, 0.1, -60);
	glRotatef(180, 0, 1, 0);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B3]);
	drawBuilding();
	glPopMatrix();

	// building 14
	glPushMatrix();
	glScalef(1, 3, 1);
	glTranslatef(-30, 0.1, -80);
	glRotatef(180, 0, 1, 0);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B4]);
	drawBuilding();
	glPopMatrix();

	glPushMatrix();
	glScalef(1, 3, 1);
	glTranslatef(-80, 0.1, 70);
	glRotatef(180, 0, 1, 0);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B4]);
	drawBuilding();
	glPopMatrix();

	glPushMatrix();
	glScalef(1, 3, 1);
	glTranslatef(-80, 0.1, 60);
	glRotatef(180, 0, 1, 0);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B4]);
	drawBuilding();
	glPopMatrix();

	glPushMatrix();
	glScalef(1, 3, 1);
	glTranslatef(-80, 0.1, 40);
	glRotatef(180, 0, 1, 0);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B1]);
	drawBuilding();
	glPopMatrix();

	glPushMatrix();
	glScalef(1, 3, 1);
	glTranslatef(-80, 0.1, 20);
	glRotatef(180, 0, 1, 0);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B4]);
	drawBuilding();
	glPopMatrix();

	glPushMatrix();
	glScalef(1, 3, 1);
	glTranslatef(-80, 0.1, 10);
	glRotatef(180, 0, 1, 0);
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, textureObjects[B4]);
	drawBuilding();
	glPopMatrix();
}
void buildingss(bool inShadow)
{
	glPushMatrix();
	glTranslatef(0, -3, 0);
	if (!inShadow)
		glColor3ub(210, 180, 140);
	else
		glColor3f(0, 0, 0);
	buildings();

	if (!inShadow)
		glColor3ub(210, 0, 140);
	else
		buildings();

	glPopMatrix();
}
void adjustLight()
{
	if (ambientFlag)
		glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);
	else
		glLightModelfv(GL_LIGHT_MODEL_AMBIENT, none);

	if (diffuseFlag)
		glLightfv(GL_LIGHT0, GL_DIFFUSE, full);
	else
		glLightfv(GL_LIGHT0, GL_DIFFUSE, none);

	if (specularFlag)
		glLightfv(GL_LIGHT0, GL_SPECULAR, full);
	else
		glLightfv(GL_LIGHT0, GL_SPECULAR, none);

	if (smoothFlag)
		glShadeModel(GL_SMOOTH);
	else
		glShadeModel(GL_FLAT);

}
///////////////////////////////////////////////////////////
// Called to draw scene
void RenderScene(void)
{
	adjustLight();
	warped = false;
	objectYRotation = fmodf(objectYRotation + 1, 360.0);

	GLUquadricObj *pObj;	// Quadric Object
	pObj = gluNewQuadric();
	gluQuadricNormals(pObj, GLU_SMOOTH);
	GLfloat horizontalMovement = 1;
	GLfloat verticalMovement = 0;
	horizontalMovement = cos(xRotationAngle*PI / 180);
	verticalMovement = -sin(xRotationAngle*PI / 180);
	horizontalMovement = MOVEDELTA;
	if (lookDown)
	{
		xRotationAngle -= ANGLEDELTA;
		if (xRotationAngle <= -90)
			xRotationAngle = -90;
	}
	if (lookUp)
	{
		xRotationAngle += ANGLEDELTA;
		if (xRotationAngle >= 90)
			xRotationAngle = 90;
	}
	if (lookLeft)
	{
		yRotationAngle -= ANGLEDELTA;
		if (yRotationAngle <= 0)
			yRotationAngle = 360;
	}
	if (lookRight)
	{
		yRotationAngle += ANGLEDELTA;
		if (yRotationAngle >= 360)
			yRotationAngle = 0;
	}
	horizontalMovement = cos(xRotationAngle*PI / 180)*MOVEDELTA;
	verticalMovement = sin(xRotationAngle*PI / 180)*MOVEDELTA;
	if (walkForward)
	{
		zCameraLocation -= cos(yRotationAngle*PI / 180)*horizontalMovement;
		xCameraLocation += sin(yRotationAngle*PI / 180)*horizontalMovement;
		yCameraLocation += verticalMovement;
	}
	if (walkBackward)
	{
		zCameraLocation += cos(yRotationAngle*PI / 180)*horizontalMovement;
		xCameraLocation -= sin(yRotationAngle*PI / 180)*horizontalMovement;
		yCameraLocation -= verticalMovement;
	}
	if (strafeRight)
	{
		zCameraLocation -= cos((yRotationAngle + 90)*PI / 180)*MOVEDELTA;
		xCameraLocation += sin((yRotationAngle + 90)*PI / 180)*MOVEDELTA;
	}
	if (strafeLeft)
	{
		zCameraLocation -= cos((yRotationAngle - 90)*PI / 180)*MOVEDELTA;
		xCameraLocation += sin((yRotationAngle - 90)*PI / 180)*MOVEDELTA;
	}

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Reset Model view matrix stack
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glRotatef(-xRotationAngle, 1, 0, 0);
	glRotatef(zRotationAngle, 0, 0, 1);
	glRotatef(yRotationAngle, 0, 1, 0);
	glTranslatef(xTranslation, yTranslation, zTranslation);
	glTranslatef(-xCameraLocation, -yCameraLocation, -zCameraLocation);

	sunRotationAngle = (sunRotationAngle + 0.5);
	if (sunRotationAngle >= 360)
		sunRotationAngle = 0;
	// Calculate projection matrix to draw shadow on the ground
	GLfloat shadowMat[4][4];
	GLfloat	 lightNewPos[] = { 150.0*cos(sunRotationAngle*PI / 180.0), 150.0*sin(sunRotationAngle*PI / 180.0), 0.0f, 1.0f };
	GLfloat groundPlane[] = { 0.0f, 1.0f, 0.0f, 0.0f };
	shadowMatrix(shadowMat, groundPlane, lightNewPos);
	
	//view transformation	
	DrawSkyBox();
	
	glBindTexture(GL_TEXTURE_2D, textureObjects[FLOOR]);
	//Base plane FLOOR
	glColor4f(1.0, 1.0, 1.0, 1.0);
	drawPlane();
	//glPopMatrix();

	glPushMatrix();
	glTranslatef(0, 0.1, 0);
	//road
	glColor3ub(0, 0, 0);
	glBegin(GL_QUADS);
	glNormal3f(0, 1, 0);
	glVertex3f(20, 0, -100);
	glVertex3f(-20, 0, -100);
	glVertex3f(-20, 0, 110);
	glVertex3f(20, 0, 110);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-60, 0.1, 0);
	//Side road
	glColor3ub(0, 0, 0);
	glBegin(GL_QUADS);
	glNormal3f(0, 1, 0);
	glVertex3f(10, 0, -100);
	glVertex3f(-10, 0, -100);
	glVertex3f(-10, 0, 110);
	glVertex3f(10, 0, 110);
	glEnd();
	glPopMatrix();

	//lines
	glColor3f(1, 1, 1);

	glBegin(GL_QUADS);
	glNormal3f(0, 1, 0);
	glVertex3f(0.5, 0, -100);
	glVertex3f(-0.5, 0, -100);
	glVertex3f(-0.5, 0, -85);
	glVertex3f(0.5, 0, -85);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, 0.2, 0);
	//lines
	glColor3f(1, 1, 1);

	glBegin(GL_QUADS);
	glNormal3f(0, 1, 0);
	glVertex3f(0.5, 0, -80);
	glVertex3f(-0.5, 0, -80);
	glVertex3f(-0.5, 0, -65);
	glVertex3f(0.5, 0, -65);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, 0.2, 0);
	// lines
	glColor3f(1, 1, 1);

	glBegin(GL_QUADS);
	glNormal3f(0, 1, 0);
	glVertex3f(0.5, 0, -60);
	glVertex3f(-0.5, 0, -60);
	glVertex3f(-0.5, 0, -45);
	glVertex3f(0.5, 0, -45);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, 0.2, 0);
	//white lines
	glColor3f(1, 1, 1);

	glBegin(GL_QUADS);
	glNormal3f(0, 1, 0);
	glVertex3f(0.5, 0, -40);
	glVertex3f(-0.5, 0, -40);
	glVertex3f(-0.5, 0, -25);
	glVertex3f(0.5, 0, -25);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, 0.2, 0);
	//lines
	glColor3f(1, 1, 1);

	glBegin(GL_QUADS);
	glNormal3f(0, 1, 0);
	glVertex3f(0.5, 0, -20);
	glVertex3f(-0.5, 0, -20);
	glVertex3f(-0.5, 0, -5);
	glVertex3f(0.5, 0, -5);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, 0.2, 0);
	// lines
	glColor3f(1, 1, 1);

	glBegin(GL_QUADS);
	glNormal3f(0, 1, 0);
	glVertex3f(0.5, 0, 0);
	glVertex3f(-0.5, 0, 0);
	glVertex3f(-0.5, 0, 15);
	glVertex3f(0.5, 0, 15);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, 0.2, 0);
	//white lines
	glColor3f(1, 1, 1);

	glBegin(GL_QUADS);
	glNormal3f(0, 1, 0);
	glVertex3f(0.5, 0, 20);
	glVertex3f(-0.5, 0, 20);
	glVertex3f(-0.5, 0, 35);
	glVertex3f(0.5, 0, 35);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, 0.2, 0);
	// lines
	glColor3f(1, 1, 1);

	glBegin(GL_QUADS);
	glNormal3f(0, 1, 0);
	glVertex3f(0.5, 0, 40);
	glVertex3f(-0.5, 0, 40);
	glVertex3f(-0.5, 0, 55);
	glVertex3f(0.5, 0, 55);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, 0.2, 0);
	//lines
	glColor3f(1, 1, 1);

	glBegin(GL_QUADS);
	glNormal3f(0, 1, 0);
	glVertex3f(0.5, 0, 60);
	glVertex3f(-0.5, 0, 60);
	glVertex3f(-0.5, 0, 75);
	glVertex3f(0.5, 0, 75);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, 0.2, 0);
	//lines
	glColor3f(1, 1, 1);
	glBegin(GL_QUADS);
	glNormal3f(0, 1, 0);
	glVertex3f(0.5, 0, 80);
	glVertex3f(-0.5, 0, 80);
	glVertex3f(-0.5, 0, 95);
	glVertex3f(0.5, 0, 95);
	glEnd();
	glPopMatrix();

	// car
	glPushMatrix();
	glRotatef(-90, 1, 0, 0);
	glRotatef(-90, 0, 0, 1);
	glTranslatef(0, 1, 1);
	car();
	glPopMatrix();

	// light source  - sun
	glColor3f(1, 0.8, 0);
	glPushMatrix();
	glRotatef(sunRotationAngle, 0, 0, 1);
	glTranslatef(150, 0, 0);
	glColor3f(1, 0, 0);
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glutSolidSphere(20, 20, 20);
	glEnable(GL_LIGHTING);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
	glEnable(GL_TEXTURE_2D);
	glPopMatrix();
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

	// traffic signal poles
	glPushMatrix();
	glTranslatef(21, 0.2, 60);
	glColor3f(1, 1, 1);
	glLineWidth(10);
	glBegin(GL_LINES);
	glVertex3f(0, 0, 0);
	glVertex3f(0, 10, 0);
	glEnd();
	glPopMatrix();

	//middle line
	glPushMatrix();
	glTranslatef(70, 0.2, 60);
	//(-90, 1, 0, 0);
	glColor3f(0, 0, 0);
	glLineWidth(10);
	glBegin(GL_LINES);
	glVertex3f(0, 0, -20);
	glVertex3f(0, 0, -100);
	glEnd();
	glPopMatrix();

	//borders
	//left border
	glPushMatrix();
	glTranslatef(100, 0.2, 60);
	glColor3f(0, 0, 0);
	glLineWidth(10);
	glBegin(GL_LINES);
	glVertex3f(0, 0, 30);
	glVertex3f(0, 0, -140);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(100, 0.2, 60);
	glColor3f(0, 0, 0);
	glLineWidth(10);
	glBegin(GL_LINES);
	glVertex3f(0, 0, 30);
	glVertex3f(-60, 0, 30);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(100, 0.2, -110);
	glColor3f(0, 0, 0);
	glLineWidth(10);
	glBegin(GL_LINES);
	glVertex3f(0, 0, 30);
	glVertex3f(-60, 0, 30);
	glEnd();
	glPopMatrix();

	//right border for court
	glPushMatrix();
	glTranslatef(40, 0.2, 60);
	glColor3f(0, 0, 0);
	glLineWidth(10);
	glBegin(GL_LINES);
	glVertex3f(0, 0, 30);
	glVertex3f(0, 0, -140);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(70, 0.2, 60);
	glColor3f(1, 1, 0);
	glLineWidth(10);
	glBegin(GL_LINES);
	glVertex3f(0, 10, 0);
	glVertex3f(-20, 10, 0);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(70, 0.2, 60);
	glColor3f(1, 1, 0);
	glLineWidth(10);
	glBegin(GL_LINES);
	glVertex3f(-20, 10, 0);
	glVertex3f(20, 10, 0);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(70, 0.2, 60);
	glColor3f(1, 1, 0);
	glLineWidth(10);
	glBegin(GL_LINES);
	glVertex3f(20, 10, 0);
	glVertex3f(20, 0, 0);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(50, 0.2, 60);
	glColor3f(1, 1, 0);
	glLineWidth(10);
	glBegin(GL_LINES);
	glVertex3f(0, 0, 0);
	glVertex3f(0, 10, 0);
	glEnd();
	glPopMatrix();

	//other side
	glPushMatrix();
	glTranslatef(50, 0.2, -60);
	glColor3f(1, 1, 0);
	glLineWidth(10);
	glBegin(GL_LINES);
	glVertex3f(0, 0, 0);
	glVertex3f(0, 10, 0);
	glEnd();
	glPopMatrix();
	
	glPushMatrix();
	glTranslatef(70, 0.2, -60);
	glColor3f(1, 1, 0);
	glLineWidth(10);
	glBegin(GL_LINES);
	glVertex3f(0, 10, 0);
	glVertex3f(-20, 10, 0);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(70, 0.2, -60);
	glColor3f(1, 1, 0);
	glLineWidth(10);
	glBegin(GL_LINES);
	glVertex3f(-20, 10, 0);
	glVertex3f(20, 10, 0);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(70, 0.2, -60);
	glColor3f(1, 1, 0);
	glLineWidth(10);
	glBegin(GL_LINES);
	glVertex3f(20, 10, 0);
	glVertex3f(20, 0, 0);
	glEnd();
	glPopMatrix();

	//foot ball
	glBindTexture(GL_TEXTURE_2D, textureObjects[BALL]);

	glColor3f(1, 1, 0);
	glPushMatrix();
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glTranslatef(69, 3.2, -7);
	glLightfv(GL_LIGHT3, GL_POSITION, lightPos);
	glBindTexture(GL_TEXTURE_2D, textureObjects[BALL]);

	glutSolidSphere(4.6, 20, 20);
	glEnable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(21, 9, 60);
	glColor3f(0, 0, 0);
	glRotatef(-90, 0, 1, 0);
	glLineWidth(3);
	glBegin(GL_LINES);
	glVertex3f(0, 0, 0);
	glVertex3f(0, 0, 18);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(16, 9, 60);
	glColor3f(0, 0, 0);
	glRotatef(180, 0, 1, 0);
	glLineWidth(3);
	glBegin(GL_LINES);

	glVertex3f(0, 0, 0);
	glVertex3f(0, -2, 0);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(10, 9, 60);
	glColor3f(0, 0, 0);
	glRotatef(180, 0, 1, 0);
	glLineWidth(3);
	glBegin(GL_LINES);

	glVertex3f(0, 0, 0);
	glVertex3f(0, -2, 0);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(4, 9, 60);
	glColor3f(0, 0, 0);
	glRotatef(180, 0, 1, 0);
	glLineWidth(3);
	glBegin(GL_LINES);

	glVertex3f(0, 0, 0);
	glVertex3f(0, -2, 0);
	glEnd();
	glPopMatrix();

	// red light
	glColor3f(1, 0, 0);
	glPushMatrix();
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glTranslatef(4, 7, 60);
	glLightfv(GL_LIGHT3, GL_POSITION, lightPos);
	glutSolidSphere(0.6, 20, 20);
	glEnable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glPopMatrix();

	// yellow light
	glColor3f(1, 0.8, 0);
	glPushMatrix();
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glTranslatef(10, 7, 60);
	glLightfv(GL_LIGHT4, GL_POSITION, lightPos);
	glutSolidSphere(0.6, 20, 20);
	glEnable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glPopMatrix();

	// green light
	glColor3f(0, 1, 0);
	glPushMatrix();
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glTranslatef(16, 7, 60);
	glLightfv(GL_LIGHT5, GL_POSITION, lightPos);
	glutSolidSphere(0.6, 20, 20);
	glEnable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glPopMatrix();

	//reflect objects and light source
	glPushMatrix();
	glScalef(1, -1, 1);
	glFrontFace(GL_CW);
	buildings();
	glFrontFace(GL_CCW);
	glPopMatrix();

	//Buildings
	glPushMatrix();
	buildings();
	glPopMatrix();
	//Shadow
	glColor3ub(0, 0, 0);
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glPushMatrix();
	glMultMatrixf((GLfloat *)shadowMat);
	     //buildingss(true);
	drawPyramids(true);
	glPopMatrix();
	glEnable(GL_LIGHTING);
	glEnable(GL_DEPTH_TEST);

	     //buildingss(false);
	drawPyramids(false);

	//blending
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glBindTexture(GL_TEXTURE_2D, textureObjects[FLOOR]);
	glDisable(GL_CULL_FACE);

	glPushMatrix();
	glColor4f(1, 1, 1, 0.8);
	glTranslatef(0, 0, 0);
	drawPlane();
	glPopMatrix();

	glPushMatrix();
	glColor4f(1, 1, 1, 0.8);
	glTranslatef(-95, 0, 105);
	drawBuilding();
	glPopMatrix();

	glDisable(GL_BLEND);
	glEnable(GL_CULL_FACE);
	glPopMatrix();

	//Particles
	glPushMatrix();
	glTranslatef(-79, 9, -51);
	drawParticles();
	glPopMatrix();

	glutSwapBuffers();
	glutPostRedisplay();
}

void TimerFunction(int value)
{
	// Redraw the scene with new coordinates
	glutPostRedisplay();
	glutTimerFunc(16, TimerFunction, 1);
}

///////////////////////////////////////////////////////////
// Setup the rendering context
// Setup the rendering context
void SetupRC(void)
{
	lookUp = false;
	lookDown = false;
	lookLeft = false;
	lookRight = false;
	walkForward = false;
	walkBackward = false;
	strafeLeft = false;
	strafeRight = false;
	yRotationAngle = 0;
	xRotationAngle = 0;
	zRotationAngle = 0;
	xCameraLocation = 0;
	yCameraLocation = 0;
	zCameraLocation = 10;
	// White background
	glClearColor(0.5f, 0.95f, 1.0f, 1.0f);
	M3DVector3f points[3] = { { -30.0f, 0.0f, -20.0f },
	{ -30.0f, 0.0f, 20.0f },
	{ 40.0f, 0.0f, 20.0f } };

	m3dGetPlaneEquation(vPlaneEquation, points[0], points[1], points[2]);

	// Set drawing color to green
	glColor3f(0.0f, 1.0f, 0.0f);

	// Set color shading model to flat
	glShadeModel(GL_SMOOTH);

	// Clock wise wound buolygons are front facing, this is reversed
	// because we are using triangle fans
	glFrontFace(GL_CCW);
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);

	// Enable lighting
	glEnable(GL_LIGHTING);

	// Setup and enable light 0
	// Supply a slight ambient light so the objects can be seen
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);

	// The light is composed of just a diffuse and specular components
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

	// Enable this light in particular
	glEnable(GL_LIGHT0);

	glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse);
	glLightfv(GL_LIGHT1, GL_SPECULAR, specular);
	glLightfv(GL_LIGHT1, GL_POSITION, lightPos);

	// Enable this light in particular
	glEnable(GL_LIGHT1);

	glLightfv(GL_LIGHT2, GL_DIFFUSE, diffuse);
	glLightfv(GL_LIGHT2, GL_SPECULAR, specular);
	glLightfv(GL_LIGHT2, GL_POSITION, lightPos);

	// Enable this light in particular
	glEnable(GL_LIGHT2);

	glLightfv(GL_LIGHT3, GL_DIFFUSE, diffuse);
	glLightfv(GL_LIGHT3, GL_SPECULAR, specular);
	glLightfv(GL_LIGHT3, GL_POSITION, lightPos);

	// Enable this light in particular
	glEnable(GL_LIGHT3);

	glLightfv(GL_LIGHT4, GL_DIFFUSE, diffuse);
	glLightfv(GL_LIGHT4, GL_SPECULAR, specular);
	glLightfv(GL_LIGHT4, GL_POSITION, lightPos);

	// Enable this light in particular
	glEnable(GL_LIGHT4);

	glLightfv(GL_LIGHT5, GL_DIFFUSE, diffuse);
	glLightfv(GL_LIGHT5, GL_SPECULAR, specular);
	glLightfv(GL_LIGHT5, GL_POSITION, lightPos);

	// Enable this light in particular
	glEnable(GL_LIGHT5);

	// Enable color tracking
	glEnable(GL_COLOR_MATERIAL);

	glEnable(GL_NORMALIZE);

	glEnable(GL_TEXTURE_2D);


	glGenTextures(NUM_TEXTURES, textureObjects);

	glBindTexture(GL_TEXTURE_2D, textureObjects[B1]);

	glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	GLbyte *pBytes;
	GLint iWidth, iHeight, iComponents;
	GLenum eFormat;
	pBytes = gltLoadTGA("bu1.tga", &iWidth, &iHeight, &iComponents, &eFormat);
	glTexImage2D(GL_TEXTURE_2D, 0, iComponents, iWidth, iHeight, 0, eFormat, GL_UNSIGNED_BYTE, pBytes);
	free(pBytes);

	glBindTexture(GL_TEXTURE_2D, textureObjects[B2]);
	//glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	pBytes = gltLoadTGA("bu5.tga", &iWidth, &iHeight, &iComponents, &eFormat);
	glTexImage2D(GL_TEXTURE_2D, 0, iComponents, iWidth, iHeight, 0, eFormat, GL_UNSIGNED_BYTE, pBytes);
	free(pBytes);

	glBindTexture(GL_TEXTURE_2D, textureObjects[B3]);
	//glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	pBytes = gltLoadTGA("bu3.tga", &iWidth, &iHeight, &iComponents, &eFormat);
	glTexImage2D(GL_TEXTURE_2D, 0, iComponents, iWidth, iHeight, 0, eFormat, GL_UNSIGNED_BYTE, pBytes);
	free(pBytes);

	glBindTexture(GL_TEXTURE_2D, textureObjects[B4]);
	//glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	pBytes = gltLoadTGA("bu4.tga", &iWidth, &iHeight, &iComponents, &eFormat);
	glTexImage2D(GL_TEXTURE_2D, 0, iComponents, iWidth, iHeight, 0, eFormat, GL_UNSIGNED_BYTE, pBytes);
	free(pBytes);

	glBindTexture(GL_TEXTURE_2D, textureObjects[B5]);
	//glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	pBytes = gltLoadTGA("bu2.tga", &iWidth, &iHeight, &iComponents, &eFormat);
	glTexImage2D(GL_TEXTURE_2D, 0, iComponents, iWidth, iHeight, 0, eFormat, GL_UNSIGNED_BYTE, pBytes);
	free(pBytes);

	glBindTexture(GL_TEXTURE_2D, textureObjects[FLOOR]);
	//glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	pBytes = gltLoadTGA("floor1.tga", &iWidth, &iHeight, &iComponents, &eFormat);
	glTexImage2D(GL_TEXTURE_2D, 0, iComponents, iWidth, iHeight, 0, eFormat, GL_UNSIGNED_BYTE, pBytes);
	free(pBytes);

	glBindTexture(GL_TEXTURE_2D, textureObjects[BALL]);
	//glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	pBytes = gltLoadTGA("ball.tga", &iWidth, &iHeight, &iComponents, &eFormat);
	glTexImage2D(GL_TEXTURE_2D, 0, iComponents, iWidth, iHeight, 0, eFormat, GL_UNSIGNED_BYTE, pBytes);
	free(pBytes);


	glBindTexture(GL_TEXTURE_2D, textureObjects[PARTICLE]);
	//glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	pBytes = gltLoadTGA("particle.tga", &iWidth, &iHeight, &iComponents, &eFormat);
	glTexImage2D(GL_TEXTURE_2D, 0, iComponents, iWidth, iHeight, 0, eFormat, GL_UNSIGNED_BYTE, pBytes);
	free(pBytes);

	initParticles();

	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_GENERATE_MIPMAP, GL_TRUE);
	// Load Cube Map images
	for (int i = 0; i < 6; i++)
	{
		// Load this texture map

		pBytes = gltLoadTGA(szCubeFaces[i], &iWidth, &iHeight, &iComponents, &eFormat);
		//gluBuild2DMipmaps(cube[i], iComponents, iWidth, iHeight, eFormat, GL_UNSIGNED_BYTE, pBytes);
		glTexImage2D(cube[i], 0, iComponents, iWidth, iHeight, 0, eFormat, GL_UNSIGNED_BYTE, pBytes);
		free(pBytes);
	}

	// Set up texture maps        
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);

	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
}
void ChangeSize(int w, int h)
{
	//GLfloat nRange = 100.0f;
	// Prevent a divide by zero
	if (h == 0)
		h = 1;

	// Set Viewport to window dimensions
	glViewport(0, 0, w, h);

	// Reset projection matrix stack
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	// Establish clipping volume (left, right, bottom, top, near, far)
	GLfloat fAspect;
	fAspect = (GLfloat)w / (GLfloat)h;
	//glOrtho(-10,10,-10,10,0,1000);
	gluPerspective(45, fAspect, 0.1, 1000);

	// Reset Model view matrix stack
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}
// Respond to arrow keys by moving the camera frame of reference
void SpecialKeys(int key, int x, int y)
{
	if (key == GLUT_KEY_UP)
		lookUp = true;

	if (key == GLUT_KEY_DOWN)
		lookDown = true;

	if (key == GLUT_KEY_LEFT)
		lookLeft = true;

	if (key == GLUT_KEY_RIGHT)
		lookRight = true;

	// Refresh the Window
	glutPostRedisplay();
}
void SpecialKeysUp(int key, int x, int y)
{
	if (key == GLUT_KEY_UP)
		lookUp = false;

	if (key == GLUT_KEY_DOWN)
		lookDown = false;

	if (key == GLUT_KEY_LEFT)
		lookLeft = false;

	if (key == GLUT_KEY_RIGHT)
		lookRight = false;

	// Refresh the Window
	glutPostRedisplay();
}

void keyboardFunc(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'w':
		walkForward = true;
		break;
	case 's':
		walkBackward = true;
		break;
	case 'a':
		strafeLeft = true;
		break;
	case 'd':
		strafeRight = true;
		break;
	case 27:
		exit(0);
		break;
	case '4':
		smoothFlag = !smoothFlag;
		break;
	case '3':
		specularFlag = !specularFlag;
		break;
	case '2':
		diffuseFlag = !diffuseFlag;
		break;
	case '1':
		ambientFlag = !ambientFlag;
		break;
	default:
		break;
	}
}

void keyboardUpFunc(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'w':
		walkForward = false;
		break;
	case 's':
		walkBackward = false;
		break;
	case 'a':
		strafeLeft = false;
		break;
	case 'd':
		strafeRight = false;
		break;
	default:
		break;
	}
}
///////////////////////////////////////////////////////////
// Main program entry point
int main(int argc, char* argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(1000, 800);
	glutCreateWindow("Final Project");
	glutReshapeFunc(ChangeSize);
	glutDisplayFunc(RenderScene);
	glutSpecialFunc(SpecialKeys);
	glutSpecialUpFunc(SpecialKeysUp);
	glutKeyboardUpFunc(keyboardUpFunc);
	glutKeyboardFunc(keyboardFunc);
	glutPassiveMotionFunc(mouseMovement);
	SetupRC();
	glutTimerFunc(16, TimerFunction, 1);
	glutMainLoop();
	return 0;
}